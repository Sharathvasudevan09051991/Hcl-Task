import { combineReducers } from 'redux';
import Product from '../reducer/Product';

export default combineReducers({
    Product
});
