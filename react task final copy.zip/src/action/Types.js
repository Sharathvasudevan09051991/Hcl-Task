//cart
export const GET_PRODUCTS = 'GET_PRODUCTS';
export const GET_CART_PRODUCTS = 'GET_PRODUCTS';
export const ADD_PRODUCT = 'ADD_PRODUCT';
export const REMOVE_PRODUCT = 'REMOVE_PRODUCT';
export const ERROR_PRODUCT = 'ERROR_PRODUCT';