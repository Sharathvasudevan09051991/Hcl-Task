import axios from 'axios';
import {ADD_PRODUCT, ERROR_PRODUCT} from './Types';

export const addToCart = (id) => async dispatch => {

    try{
        const res = await axios.get(`https://fakestoreapi.com/products/${id}`,);
        dispatch({
            type: ADD_PRODUCT,
            payload: res.data
          });
    }
    catch (err){
        dispatch({
            type: ERROR_PRODUCT,
            payload: err.message
          });
    }
}

// export const deleteCartitem = (id) => async dispatch => {

//     try{
//         const res = await axios.get(`https://fakestoreapi.com/products/${id}`,);
//         dispatch({
//             type: REMOVE_PRODUCT,
//             payload: res.data
//           });
//     }
//     catch (err){

//         dispatch({
//             type: ERROR_PRODUCT,
//             payload: err.message
//           });
//     }
// }

