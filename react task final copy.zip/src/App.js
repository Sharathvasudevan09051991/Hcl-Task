import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { Header } from './layout/Header';
import ProductList from '../src/home/ProductList';
import Cart from './home/Cart';

// Redux
import { Provider } from 'react-redux';
import store from './store';


function App() {
  return (
    <div className="App"> 
        <Provider store={store}>
      <Router>
        <Header />
      <Switch>
        <Route exact path="/" component={ProductList} />
        <Route  path="/cart" component={Cart} />
        </Switch>
      </Router>
      </Provider>

    </div>
  );
}

export default App;
