import React, { useEffect } from "react";
import { useState } from "react";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { useSelector, useDispatch } from "react-redux";
import { getProducts } from "../action/Product";
import { addToCart } from "../action/Cart";
import Grid from "@material-ui/core/Grid";
import { Paper } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { useHistory } from "react-router-dom";
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const ProductList = () => {
  const classes = useStyles();

  const [products, setProducts] = useState([]);

  const shoppingProducts = useSelector((state) => state.Product.products);

  const isLoading = useSelector((state) => state.Product.loading);


  const cart = useSelector((state) => state.Cart.cart);

  const history = useHistory();

  const dispatch = useDispatch();

  console.log("Cart:", cart);

  const handleProducttoCart = (id) => {
    dispatch(addToCart(id));
    alert("Item added Successfully");
  };

  useEffect(() => {
    dispatch(getProducts());
  }, [getProducts]);

  useEffect(() => {
    setProducts(shoppingProducts);
  }, [shoppingProducts]);

  return (
    <div className={classes.root}>
      <Grid container spacing={3}>
        <Grid item xs={6} sm={5}>
          <Paper>
            {products.map((product, index) => (
              <Card key={product.id}>
                <CardActionArea>
                  <CardMedia
                    src={product.image}
                    title="Contemplative Reptile"
                  />
                  <center>
                    <img src={product.image} style={{ width: "150px" }} />
                  </center>
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="h2">
                      {product.title}
                      {product.price}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="textSecondary"
                      component="p"
                    >
                      {product.description}
                    </Typography>
                  </CardContent>
                </CardActionArea>
                <CardActions>
                  <Button
                    onClick={() => handleProducttoCart(product.id)}
                    variant="outlined"
                    color="secondary"
                    align="center"
                    startIcon={<ShoppingCartIcon />}
                  >
                    Add to Cart
                  </Button>
                </CardActions>
              </Card>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default ProductList;
