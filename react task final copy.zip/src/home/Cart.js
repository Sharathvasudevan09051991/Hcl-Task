import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Delete";


import Button from '@material-ui/core/Button';

const Cart = () => {
  const cart = useSelector((state) => state.Cart.cart);

  const [cartItems, setcartItems] = useState(cart);

  useEffect(() => {
    setcartItems(cart);
    console.log(cart);
  }, [cart]);

  const handleDelete = (id) => {
    console.log(id);
  }

  return (
    <div>
        {cart.length > 0 ? 
      <table className="table-striped border" style={{width: '100%'}} border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Title</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map((item, index) => (
            <tr>
              <td scope="row">{item.id}</td>
              <td>
                <img src={item.image} style={{ width: "50px" }} />
              </td>
              <td>{item.title}</td>
              <td>{item.price}</td>
              <td>
              <Button
                  variant="contained"
                  color="secondary"
                  startIcon={<EditIcon />}
                >
                  Edit
                </Button>
               
                <Button
                  variant="contained"
                  color="secondary"
                  startIcon={<DeleteIcon />}
                  onClick={() => handleDelete(item.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
          </table> : <h3>Cart is Empty</h3>}
    </div>
  );
};

export default Cart;
