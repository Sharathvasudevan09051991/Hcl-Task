import {ADD_PRODUCT, GET_CART_PRODUCTS} from '../action/Types';

const initialState = {
    cart: [],
    loading: true,
    error: {}
  };


export default (state = initialState, { type, payload }) => {
    switch (type) {

    case ADD_PRODUCT:
        return { 
            ...state, 
            cart: [payload, ...state.cart],
            loading: false
         }

    default:
        return state
    }
}
