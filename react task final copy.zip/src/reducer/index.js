import { combineReducers } from 'redux';
import Product from '../reducer/Product';
import Cart from '../reducer/Cart';

export default combineReducers({
    Product,
    Cart
});
