import {GET_PRODUCTS, ERROR_PRODUCT} from '../action/Types';

const initialState = {
    products: [],
    loading: true,
    error: {}
  };


export default (state = initialState, { type, payload }) => {
    switch (type) {

    case GET_PRODUCTS:
        return { 
            ...state, 
            products: payload,
            loading: false
         }

    default:
        return state
    }
}
