import React, { useEffect } from "react";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import { useHistory } from "react-router-dom";
import { useSelector } from "react-redux";


export const Header = () => {

  const cart = useSelector((state) => state.Cart.cart);
  
  useEffect(() => {
    console.log("LENGTH: ", cart);
  }, []);

  const history = useHistory();

  return (
    <div>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6">Shopping Cart</Typography>
          <ShoppingCartIcon onClick={() => history.push('/cart')} />

            
        </Toolbar>
      </AppBar>
    </div>
  );
};
